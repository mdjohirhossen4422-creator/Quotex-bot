import base64
import os
from pathlib import Path
import requests

def upload_to_github(workspace: Path):
    token = os.getenv("GITHUB_TOKEN", "").strip()
    repo = os.getenv("GITHUB_REPO", "").strip()  # owner/name
    branch = os.getenv("GITHUB_BRANCH", "main").strip()
    if not token or not repo or "/" not in repo:
        raise RuntimeError("Set GITHUB_TOKEN and GITHUB_REPO=owner/repository")
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    count = 0
    for path in sorted(workspace.rglob("*")):
        if not path.is_file() or path.name in {".env", "credentials.json", "id_rsa", "id_ed25519"}:
            continue
        if any(part in {".git", "__pycache__"} for part in path.parts):
            continue
        rel = path.relative_to(workspace).as_posix()
        url = f"https://api.github.com/repos/{repo}/contents/{rel}"
        content = path.read_bytes()
        payload = {
            "message": f"AI Builder: add/update {rel}",
            "content": base64.b64encode(content).decode("ascii"),
            "branch": branch,
        }
        existing = requests.get(url, headers=headers, params={"ref": branch}, timeout=25)
        if existing.status_code == 200:
            payload["sha"] = existing.json()["sha"]
        elif existing.status_code != 404:
            raise RuntimeError(f"GitHub lookup failed for {rel}: {existing.status_code} {existing.text[:300]}")
        response = requests.put(url, headers=headers, json=payload, timeout=45)
        if response.status_code not in (200, 201):
            raise RuntimeError(f"GitHub upload failed for {rel}: {response.status_code} {response.text[:500]}")
        count += 1
    return count, f"https://github.com/{repo}"

def trigger_render_deploy():
    token = os.getenv("RENDER_API_KEY", "").strip()
    service_id = os.getenv("RENDER_SERVICE_ID", "").strip()
    if not token or not service_id:
        raise RuntimeError("Set RENDER_API_KEY and RENDER_SERVICE_ID")
    response = requests.post(
        f"https://api.render.com/v1/services/{service_id}/deploys",
        headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        json={"clearCache": "do_not_clear"},
        timeout=30,
    )
    if response.status_code not in (200, 201, 202):
        raise RuntimeError(f"Render API error {response.status_code}: {response.text[:700]}")
    data = response.json()
    deploy_id = data.get("id") or data.get("deploy", {}).get("id", "submitted")
    return f"Deploy ID: {deploy_id}"
