# Rifat AI App Builder (Telegram + OpenAI + Render)

A Telegram bot that uses the OpenAI Responses API to generate project source files, fix a generated project, send a ZIP, upload files to an existing GitHub repository, and trigger a deploy on an existing Render service.

## Important limits
- Generated code is saved as text files and is **not executed** by this bot.
- `/github` uploads to an existing repository (`GITHUB_REPO=owner/repo`) and branch.
- `/deploy` triggers a deploy for an existing Render service already connected to that repository. It does not create a new Render service or configure the service's environment.
- Render's local filesystem is ephemeral. Download the ZIP or upload to GitHub to keep generated files.
- Live game/trading analysis requires a legitimate data source/API. The builder should not invent live data or guarantee predictions.
- Never paste API tokens into Telegram chats or source code. Use Render Environment settings.

## Local setup
1. Create a Telegram bot with @BotFather and copy its **new** token.
2. Create an OpenAI API key at https://platform.openai.com/api-keys.
3. Copy `.env.example` to `.env` and fill the values.
4. Install and run:
   ```bash
   python -m venv .venv
   # Windows: .venv\Scripts\activate
   # Linux/macOS: source .venv/bin/activate
   pip install -r requirements.txt
   python bot.py
   ```

## Render setup
1. Push this project to your own GitHub repository.
2. In Render, create a **Web Service** from that repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `python bot.py`
5. Add environment variables from `.env.example` in Render. Set `ADMIN_USER_ID` to your numeric Telegram account ID to restrict use.
6. Deploy. Health check: `/health`.

## Commands
- `/start`
- `/create` then describe the app
- `/fix` then describe the change or bug
- `/files`
- `/zip`
- `/github`
- `/deploy`
- `/status`
- `/cancel`

## GitHub / Render integration
Create a GitHub fine-grained token with access only to the target repository and Contents: Read and write. Set `GITHUB_REPO=owner/repo`.
Create a Render API key and find the existing service ID in the Render dashboard. Set `RENDER_SERVICE_ID`. The Render service must already be linked to the same GitHub repository.

## Security
- Keep `.env` out of Git.
- Rotate any Telegram token previously shared publicly.
- Set `ADMIN_USER_ID`.
- Do not give the bot tokens as prompts. The project generator rejects common secret-file names and blocks unsafe paths.
