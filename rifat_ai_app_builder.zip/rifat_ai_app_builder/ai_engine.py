import json
import os
import re
from pathlib import Path
from openai import OpenAI

MODEL = os.getenv("OPENAI_MODEL", "gpt-5.5")
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

SYSTEM = """You are a senior software engineer and project generator.
Return ONLY valid JSON with this exact shape:
{"files":[{"path":"relative/path.ext","content":"complete file content"}],"summary":"short summary"}
Generate a complete, runnable project from the user's specification.
Include README.md and all required source/config files. Use safe relative paths.
Never include secrets, API keys, tokens, passwords, or real credentials.
Use environment variables for secrets and include a .env.example with placeholders only.
Do not claim deployment has happened. Do not include binary files.
Keep the project practical and self-contained. If live data requires a third-party API,
document the required environment variables and clearly label unavailable/mock data.
Do not create malware, credential theft, destructive code, or code that bypasses access controls.
"""

def _call(prompt: str) -> dict:
    response = client.responses.create(
        model=MODEL,
        instructions=SYSTEM,
        input=prompt,
        max_output_tokens=16000,
    )
    raw = response.output_text.strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"AI returned invalid project JSON: {exc}") from exc
    if not isinstance(data, dict) or not isinstance(data.get("files"), list):
        raise RuntimeError("AI response did not contain a files list")
    return data

def generate_project(user_prompt: str) -> dict:
    return _call(
        "Create a complete software project for this request. "
        "Return all files with full content. User request:\n" + user_prompt
    )

def fix_project(change_request: str, existing_files: dict) -> dict:
    compact = []
    total = 0
    for name, content in existing_files.items():
        piece = f"\n--- FILE: {name} ---\n{content}\n"
        if total + len(piece) > 50000:
            break
        compact.append(piece)
        total += len(piece)
    prompt = (
        "Update/fix the existing project according to this request. "
        "Return the FULL updated contents of every file that should exist in the final project, "
        "not diffs. Preserve unrelated functionality.\n"
        f"Change request: {change_request}\n"
        "Existing project files:\n" + "".join(compact)
    )
    return _call(prompt)
