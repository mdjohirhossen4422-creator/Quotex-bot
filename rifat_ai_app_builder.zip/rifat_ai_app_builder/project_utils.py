import json
import os
import re
import zipfile
from pathlib import Path

ALLOWED_EXTENSIONS = {
    ".py", ".html", ".htm", ".css", ".js", ".jsx", ".ts", ".tsx",
    ".json", ".md", ".txt", ".yml", ".yaml", ".toml", ".ini",
    ".sh", ".sql", ".xml", ".svg", ".gitignore", ".env.example",
    ".csv", ".dockerignore"
}
BLOCKED_NAMES = {".env", "id_rsa", "id_ed25519", "credentials.json"}

def safe_workspace(root: Path, user_id: str) -> Path:
    safe_id = re.sub(r"[^0-9]", "", str(user_id))
    path = (root / safe_id).resolve()
    path.mkdir(parents=True, exist_ok=True)
    if root.resolve() not in path.parents:
        raise ValueError("Invalid workspace path")
    return path

def _safe_relative(raw: str) -> Path:
    raw = str(raw).replace("\\", "/").strip()
    p = Path(raw)
    if not raw or p.is_absolute() or ".." in p.parts:
        raise ValueError(f"Unsafe file path: {raw}")
    if any(part.startswith(".") and part not in {".github", ".gitignore", ".env.example", ".dockerignore"} for part in p.parts):
        raise ValueError(f"Hidden path is not allowed: {raw}")
    if p.name in BLOCKED_NAMES:
        raise ValueError(f"Secret file is not allowed: {raw}")
    suffix = p.suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS and p.name not in {".gitignore", ".env.example", ".dockerignore", "Dockerfile", "Procfile"}:
        raise ValueError(f"File type is not allowed: {raw}")
    return p

def save_project(workspace: Path, project: dict) -> list[str]:
    files = project.get("files", [])
    if not isinstance(files, list) or not files:
        raise ValueError("AI returned no files")
    saved = []
    total = 0
    for item in files:
        if not isinstance(item, dict) or "path" not in item or "content" not in item:
            continue
        rel = _safe_relative(item["path"])
        content = item["content"]
        if not isinstance(content, str):
            raise ValueError(f"File content must be text: {rel}")
        total += len(content.encode("utf-8"))
        if total > 2_000_000:
            raise ValueError("Project is larger than 2 MB")
        target = (workspace / rel).resolve()
        if workspace.resolve() not in target.parents:
            raise ValueError("Path escaped workspace")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        saved.append(rel.as_posix())
    if not saved:
        raise ValueError("No valid files were saved")
    summary = project.get("summary", "")
    (workspace / "AI_BUILD_SUMMARY.txt").write_text(str(summary)[:5000], encoding="utf-8")
    saved.append("AI_BUILD_SUMMARY.txt")
    return saved

def list_project_files(workspace: Path) -> dict:
    if not workspace.exists():
        return {}
    result = {}
    for path in sorted(workspace.rglob("*")):
        if not path.is_file():
            continue
        if path.name in BLOCKED_NAMES or path.name == ".env":
            continue
        if any(part in {".git", "__pycache__"} for part in path.parts):
            continue
        try:
            result[path.relative_to(workspace).as_posix()] = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
    return result

def make_zip(workspace: Path) -> Path:
    archive = workspace.parent / f"project_{workspace.name}.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in workspace.rglob("*"):
            if not path.is_file() or path.name in BLOCKED_NAMES or path.name == ".env":
                continue
            if any(part in {".git", "__pycache__"} for part in path.parts):
                continue
            zf.write(path, path.relative_to(workspace).as_posix())
    return archive
