import asyncio
import logging
import os
import threading
from pathlib import Path

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, ContextTypes, MessageHandler, filters
)

from ai_engine import generate_project, fix_project
from project_utils import save_project, list_project_files, make_zip, safe_workspace

load_dotenv()

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=os.getenv("LOG_LEVEL", "INFO"),
)
log = logging.getLogger("rifat-ai-builder")

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
ADMIN_USER_ID = os.getenv("ADMIN_USER_ID", "").strip()
WORKSPACES = Path(os.getenv("WORKSPACES_DIR", "/tmp/rifat_ai_workspaces"))
MAX_TELEGRAM_TEXT = 3900

web = Flask(__name__)

@web.get("/")
def home():
    return "Rifat AI App Builder is running.", 200

@web.get("/health")
def health():
    return jsonify(status="ok", service="rifat-ai-app-builder"), 200

def start_health_server():
    port = int(os.getenv("PORT", "10000"))
    web.run(host="0.0.0.0", port=port, use_reloader=False, threaded=True)

def is_allowed(update: Update) -> bool:
    if not ADMIN_USER_ID:
        return True
    user = update.effective_user
    return bool(user and str(user.id) == ADMIN_USER_ID)

async def guard(update: Update) -> bool:
    if not is_allowed(update):
        await update.effective_message.reply_text("এই Bot ব্যবহারের অনুমতি তোমার নেই।")
        return False
    return True

def user_workspace(user_id: int) -> Path:
    return safe_workspace(WORKSPACES, str(user_id))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    keyboard = [
        ["/create", "/fix"],
        ["/files", "/zip"],
        ["/github", "/deploy"],
        ["/status", "/cancel"],
    ]
    await update.message.reply_text(
        "🤖 RIFAT AI APP BUILDER\n\n"
        "তোমার App-এর বর্ণনা /create দিয়ে পাঠাও। আমি source code ও project files তৈরি করব।\n\n"
        "Commands:\n"
        "/create - নতুন App তৈরি\n"
        "/fix - সর্বশেষ project-এর bug fix\n"
        "/files - project files দেখো\n"
        "/zip - project ZIP নাও\n"
        "/github - GitHub repository-তে upload\n"
        "/deploy - Render deploy trigger\n"
        "/status - configuration status\n"
        "/cancel - চলতি request বাতিল",
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True),
    )

async def create_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    context.user_data["mode"] = "create"
    await update.message.reply_text(
        "কী App বানাতে চাও? বিস্তারিত লিখে পাঠাও।\n"
        "যেমন: Create a responsive football live match analysis dashboard with team stats."
    )

async def fix_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    context.user_data["mode"] = "fix"
    await update.message.reply_text(
        "সর্বশেষ তৈরি project-এর কোন bug বা পরিবর্তন ঠিক করতে হবে? লিখে পাঠাও।"
    )

async def cancel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("mode", None)
    await update.message.reply_text("চলতি request বাতিল করা হয়েছে।")

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    mode = context.user_data.get("mode")
    if not mode:
        await update.message.reply_text("নতুন App বানাতে /create অথবা bug ঠিক করতে /fix ব্যবহার করো।")
        return

    prompt = (update.message.text or "").strip()
    if not prompt:
        await update.message.reply_text("একটি বিস্তারিত নির্দেশনা পাঠাও।")
        return
    if len(prompt) > 12000:
        await update.message.reply_text("নির্দেশনা ১২,০০০ অক্ষরের মধ্যে রাখো।")
        return

    context.user_data.pop("mode", None)
    user_id = update.effective_user.id
    workspace = user_workspace(user_id)
    status = await update.message.reply_text("⏳ AI কাজ শুরু করেছে। একটু অপেক্ষা করো...")

    try:
        if mode == "create":
            project = await asyncio.to_thread(generate_project, prompt)
            saved = save_project(workspace, project)
        else:
            existing = list_project_files(workspace)
            if not existing:
                await status.edit_text("আগে /create দিয়ে একটি project তৈরি করো।")
                return
            project = await asyncio.to_thread(fix_project, prompt, existing)
            saved = save_project(workspace, project)

        names = [p for p in saved]
        preview = "\n".join(f"• {n}" for n in names[:35])
        if len(names) > 35:
            preview += f"\n...আরও {len(names)-35}টি file"
        await status.edit_text(
            f"✅ Project তৈরি/আপডেট হয়েছে।\n\n"
            f"Files: {len(names)}\n{preview}\n\n"
            "এখন /zip দিয়ে ZIP নাও, /github দিয়ে repository-তে upload করো।"
        )
    except Exception as exc:
        log.exception("Project generation failed")
        msg = str(exc).replace("<", "").replace(">", "")[:1200]
        await status.edit_text(f"❌ Build failed:\n{msg}")

async def files_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    names = list_project_files(user_workspace(update.effective_user.id))
    if not names:
        await update.message.reply_text("এখনো কোনো project নেই। /create দিয়ে শুরু করো।")
        return
    text = "📁 Project files:\n" + "\n".join(f"• {n}" for n in names[:100])
    await update.message.reply_text(text[:MAX_TELEGRAM_TEXT])

async def zip_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    workspace = user_workspace(update.effective_user.id)
    names = list_project_files(workspace)
    if not names:
        await update.message.reply_text("আগে /create দিয়ে App তৈরি করো।")
        return
    archive = make_zip(workspace)
    with archive.open("rb") as f:
        await update.message.reply_document(document=f, filename="rifat_ai_project.zip",
                                             caption="তোমার generated project ZIP")
    archive.unlink(missing_ok=True)

async def github_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    await update.message.reply_text("GitHub upload শুরু করছি...")
    try:
        from integrations import upload_to_github
        count, url = await asyncio.to_thread(
            upload_to_github, user_workspace(update.effective_user.id)
        )
        await update.message.reply_text(f"✅ {count}টি file GitHub-এ upload হয়েছে।\n{url}")
    except Exception as exc:
        log.exception("GitHub upload failed")
        await update.message.reply_text(f"❌ GitHub upload failed: {str(exc)[:900]}")

async def deploy_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    try:
        from integrations import trigger_render_deploy
        result = await asyncio.to_thread(trigger_render_deploy)
        await update.message.reply_text(
            "✅ Render deploy trigger করা হয়েছে।\n"
            "এটি আগে থেকে GitHub repo-র সঙ্গে connected Render service-এ deploy করবে।\n"
            + result
        )
    except Exception as exc:
        log.exception("Render deploy failed")
        await update.message.reply_text(f"❌ Render deploy failed: {str(exc)[:900]}")

async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await guard(update):
        return
    checks = {
        "Telegram token": bool(BOT_TOKEN),
        "OpenAI API key": bool(os.getenv("OPENAI_API_KEY")),
        "GitHub token + repo": bool(os.getenv("GITHUB_TOKEN") and os.getenv("GITHUB_REPO")),
        "Render token + service": bool(os.getenv("RENDER_API_KEY") and os.getenv("RENDER_SERVICE_ID")),
    }
    lines = [f"{'✅' if ok else '❌'} {name}" for name, ok in checks.items()]
    await update.message.reply_text("⚙️ Configuration:\n" + "\n".join(lines))

def main():
    if not BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN environment variable is missing")
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY environment variable is missing")

    threading.Thread(target=start_health_server, daemon=True, name="health-server").start()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("create", create_cmd))
    app.add_handler(CommandHandler("fix", fix_cmd))
    app.add_handler(CommandHandler("cancel", cancel_cmd))
    app.add_handler(CommandHandler("files", files_cmd))
    app.add_handler(CommandHandler("zip", zip_cmd))
    app.add_handler(CommandHandler("github", github_cmd))
    app.add_handler(CommandHandler("deploy", deploy_cmd))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    log.info("Rifat AI App Builder starting")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
